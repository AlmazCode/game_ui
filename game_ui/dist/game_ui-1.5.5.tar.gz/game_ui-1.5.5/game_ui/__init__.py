from .buttons import Button, roundButton, Buttons
from .input import Input, inputs
from .text import Text, Texts

__author__ = 'AlmazCode'
__version__ = '1.5.5'
__email__ = 'diamondplay43@gmail.com'