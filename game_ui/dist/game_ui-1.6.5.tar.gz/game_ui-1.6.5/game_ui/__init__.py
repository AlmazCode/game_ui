from .button import Button, Buttons
from .input import Input, inputs

__author__ = 'AlmazCode'
__version__ = '1.6.5'
__email__ = 'diamondplay43@gmail.com'